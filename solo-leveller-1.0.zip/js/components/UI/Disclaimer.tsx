import React from 'react';
import Modal from './Modal';
import Button from './Button';
import { DISCLAIMER_TEXT } from '../../../constants';

interface DisclaimerProps {
  isOpen: boolean;
  onAcknowledge: () => void;
}

const Disclaimer: React.FC<DisclaimerProps> = ({ isOpen, onAcknowledge }) => {
  return (
    <Modal
      isOpen={isOpen}
      title="SYSTEM WARNING"
      persistent={true} // User must acknowledge
      className="max-w-xl"
    >
      <div className="text-gray-300 text-sm md:text-base leading-relaxed whitespace-pre-wrap text-center">
        {DISCLAIMER_TEXT}
      </div>
      <div className="flex justify-center mt-6">
        <Button onClick={onAcknowledge} className="w-full max-w-[200px]">
          ACKNOWLEDGE
        </Button>
      </div>
    </Modal>
  );
};

export default Disclaimer;
